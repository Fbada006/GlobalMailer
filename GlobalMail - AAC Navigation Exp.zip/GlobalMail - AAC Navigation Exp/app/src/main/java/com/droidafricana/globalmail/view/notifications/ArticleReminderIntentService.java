package com.droidafricana.globalmail.view.notifications;

import android.app.IntentService;
import android.content.Intent;
import androidx.annotation.Nullable;

public class ArticleReminderIntentService extends IntentService {

    public ArticleReminderIntentService() {
        super("ArticleReminderIntentService");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        assert intent != null;
        String action = intent.getAction();
        ArticleNotificationTasks.executeTask(this, action);
    }
}
