package com.droidafricana.globalmail.service.model

import com.google.gson.annotations.SerializedName

import java.util.ArrayList

class ArticleResponse {
    @SerializedName("articles")
    val articleList: List<Article> = ArrayList()
}
