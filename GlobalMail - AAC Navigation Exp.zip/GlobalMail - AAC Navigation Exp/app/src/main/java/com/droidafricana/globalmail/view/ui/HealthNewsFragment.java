package com.droidafricana.globalmail.view.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.airbnb.lottie.LottieAnimationView;
import com.droidafricana.globalmail.R;
import com.droidafricana.globalmail.utils.FragmentUtils;
import com.droidafricana.globalmail.utils.PrefUtils;
import com.droidafricana.globalmail.view.adapter.MyArticleAdapter;
import com.droidafricana.globalmail.viewModel.ArticleViewModel;
import com.droidafricana.globalmail.viewModel.ArticleViewModelFactory;

import java.util.Objects;

public class HealthNewsFragment extends Fragment {

    public static final String TAG = HealthNewsFragment.class.getSimpleName();
    private MyArticleAdapter mMyArticleAdapter;
    private LottieAnimationView mProgressBar;
    private LottieAnimationView mNoConnection;
    private LinearLayout mNoArticlesFound;
    private ArticleViewModel mArticleViewModel;

    public HealthNewsFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.my_news_fragment, container, false);

        setHasOptionsMenu(true);

        mNoConnection = view.findViewById(R.id.av_no_internet_connection);
        RecyclerView recyclerView = view.findViewById(R.id.recycler_view);
        mProgressBar = view.findViewById(R.id.av_progress_bar);
        SwipeRefreshLayout swipeRefreshLayout = view.findViewById(R.id.layout_swipe_refresh);
        mNoArticlesFound = view.findViewById(R.id.layout_no_articles_found);
        StaggeredGridLayoutManager gridLayoutManager =
                new StaggeredGridLayoutManager(Objects.requireNonNull(getActivity()).getResources().getInteger(R.integer.column_article_count),
                        StaggeredGridLayoutManager.VERTICAL);

        recyclerView.setLayoutManager(gridLayoutManager);
        mMyArticleAdapter = new MyArticleAdapter(Objects.requireNonNull(getContext()));
        recyclerView.setAdapter(mMyArticleAdapter);

        ArticleViewModelFactory articleViewModelFactory =
                new ArticleViewModelFactory(getActivity(), PrefUtils.categoryHealth(getActivity()));

        mArticleViewModel =
                ViewModelProviders.of(this, articleViewModelFactory).get(ArticleViewModel.class);

        FragmentUtils.observeViewModelForArticles(getActivity(), this, mArticleViewModel, mNoConnection,
                mNoArticlesFound, mProgressBar, mMyArticleAdapter);

        refreshUI(swipeRefreshLayout);

        checkIfPreferencesHaveBeenUpdated();

        return view;
    }


    private void refreshUI(final SwipeRefreshLayout refreshLayout) {
        refreshLayout.setOnRefreshListener(() -> {
            mArticleViewModel.getArticleList(getActivity(), PrefUtils.categoryHealth(getActivity()));
            FragmentUtils.observeViewModelForArticles(getActivity(), this, mArticleViewModel, mNoConnection,
                    mNoArticlesFound, mProgressBar, mMyArticleAdapter);
            refreshLayout.setRefreshing(false);
        });
        refreshLayout.setColorSchemeColors(Objects.requireNonNull(getActivity()).getResources().getColor(R.color.colorAccent));
    }

    private void checkIfPreferencesHaveBeenUpdated() {
        if (SettingsFragment.PREFERENCES_HAVE_BEEN_UPDATED) {
            mArticleViewModel.getArticleList(getActivity(), PrefUtils.categoryHealth(getActivity()));
            FragmentUtils.observeViewModelForArticles(getActivity(), this, mArticleViewModel, mNoConnection,
                    mNoArticlesFound, mProgressBar, mMyArticleAdapter);
        }
        SettingsFragment.PREFERENCES_HAVE_BEEN_UPDATED = false;
    }
}
