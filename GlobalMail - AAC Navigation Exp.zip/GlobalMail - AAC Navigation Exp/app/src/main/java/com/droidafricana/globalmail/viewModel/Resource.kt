package com.droidafricana.globalmail.viewModel

import com.droidafricana.globalmail.service.model.Article

/*Class for wrapping the article LiveData so that state can be observed in the fragment*/
class Resource<T> private constructor(val status: Resource.Status, val data: List<Article>?) {
    enum class Status {
        SUCCESS, ERROR, LOADING, NO_NETWORK
    }

    companion object {
        fun <T> success(data: List<Article>?): Resource<T> {
            return Resource(Status.SUCCESS, data)
        }

        fun <T> error(): Resource<T> {
            return Resource(Status.ERROR, null)
        }

        fun <T> loading(): Resource<T> {
            return Resource(Status.LOADING, null)
        }

        fun <T> networkError(): Resource<T> {
            return Resource(Status.NO_NETWORK, null)
        }
    }
}