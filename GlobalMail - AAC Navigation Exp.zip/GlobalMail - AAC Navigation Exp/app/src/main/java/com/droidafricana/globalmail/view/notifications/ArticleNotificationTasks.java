package com.droidafricana.globalmail.view.notifications;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;

import androidx.annotation.NonNull;

import com.droidafricana.globalmail.R;
import com.droidafricana.globalmail.service.model.Article;
import com.droidafricana.globalmail.service.model.ArticleResponse;
import com.droidafricana.globalmail.service.repository.ArticleApiService;
import com.droidafricana.globalmail.service.repository.RetrofitInstance;
import com.droidafricana.globalmail.utils.NotificationUtils;
import com.droidafricana.globalmail.utils.PrefUtils;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.droidafricana.globalmail.service.repository.ArticleApiService.API_KEY;

public class ArticleNotificationTasks {

    private static final String TAG = "ArticleNotificationTask";
    public static final String ACTION_DISMISS_NOTIFICATION = "dismiss-article-notification";
    public static final String ACTION_ISSUE_ARTICLE_NOTIFICATION = "new-article-notification";
    private static Article sArticle;

    public static void executeTask(Context context, String action) {
        if (ACTION_DISMISS_NOTIFICATION.equals(action)) {
            NotificationUtils.clearAllNotifications(context, sArticle);
        } else if (ACTION_ISSUE_ARTICLE_NOTIFICATION.equals(action)) {
            if (PrefUtils.areNotificationsEnabled(context)) {
                issueArticleNotification(context);
            }
        }
    }

    private static void issueArticleNotification(final Context context) {
        ArticleApiService articleApiService = RetrofitInstance.getInstance().create(ArticleApiService.class);

        Call<ArticleResponse> call = articleApiService.getArticleList(
                context.getString(R.string.pref_endpoint_top_news_value), PrefUtils.getQueryParam(context),
                PrefUtils.categoryGeneral(context), PrefUtils.getCountry(context),
                1, PrefUtils.getSortByParam(context), API_KEY);

        call.enqueue(new Callback<ArticleResponse>() {
            @Override
            public void onResponse(@NonNull Call<ArticleResponse> call, @NonNull Response<ArticleResponse> response) {
                assert response.body() != null;
                List<Article> mArticleList = response.body().getArticleList();
                //Get the first article to create the notification
                sArticle = mArticleList.get(0);
                //Send the notification with the relevant article and vibrate device
                NotificationUtils.sendArticleNotificationToUser(context, sArticle);
                //Vibrate the device
                vibrateDevice(context);
            }

            @Override
            public void onFailure(@NonNull Call<ArticleResponse> call, @NonNull Throwable throwable) {
                //Do nothing for now
            }
        });

    }

    private static void vibrateDevice(Context context) {
        Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        // Vibrate for 500 milliseconds
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            assert vibrator != null;
            vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
        }
        //For other devices running below API 26
        assert vibrator != null;
        vibrator.vibrate(500);
    }
}