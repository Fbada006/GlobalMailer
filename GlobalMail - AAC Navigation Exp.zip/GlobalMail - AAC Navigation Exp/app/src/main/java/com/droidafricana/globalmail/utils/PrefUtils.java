package com.droidafricana.globalmail.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.droidafricana.globalmail.R;

import java.util.Objects;

public class PrefUtils {

    public static String getSortByParam(Context context) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        return sharedPreferences.getString(
                context.getString(R.string.pref_sort_by_key),
                context.getString(R.string.pref_sort_by_default));
    }

    public static String getQueryParam(final Context context) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        return sharedPreferences.getString(
                context.getString(R.string.pref_query_key),
                null);
    }

    public static String getEndpoint(Context context) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        return sharedPreferences.getString(
                context.getString(R.string.pref_endpoint_key),
                context.getString(R.string.pref_endpoint_default));
    }

    public static String getCountry(Context context) {
        if (isEndPointEverything(context)) return null;

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        return sharedPreferences.getString(
                context.getString(R.string.pref_country_news_to_display_key),
                context.getString(R.string.pref_country_news_to_display_default));
    }

    private static boolean isEndPointEverything(Context context) {
        String endPoint = getEndpoint(context);
        return Objects.equals(endPoint, "everything");
    }

    /*Simple helper methods for the category*/
    public static String categoryGeneral(Context context) {
        if (isEndPointEverything(context)) return null;
        return context.getString(R.string.category_general_value);
    }

    public static String categorySports(Context context) {
        if (isEndPointEverything(context)) return null;
        return context.getString(R.string.category_sports_value);
    }

    public static String categoryEnt(Context context) {
        if (isEndPointEverything(context)) return null;
        return context.getString(R.string.category_entertainment_value);
    }

    public static String categoryTech(Context context) {
        if (isEndPointEverything(context)) return null;
        return context.getString(R.string.category_technology_value);
    }

    public static String categoryBus(Context context) {
        if (isEndPointEverything(context)) return null;
        return context.getString(R.string.category_business_value);
    }

    public static String categoryHealth(Context context) {
        if (isEndPointEverything(context)) return null;
        return context.getString(R.string.category_health_value);
    }

    public static String categoryScience(Context context) {
        if (isEndPointEverything(context)) return null;
        return context.getString(R.string.category_science_value);
    }

    public static boolean areNotificationsEnabled(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context)
                .getBoolean(
                        context.getString(R.string.pref_notifications_key),
                        context.getResources().getBoolean(R.bool.notification_default_value));
    }

    public static int notificationInterval(Context context) {
        String string = PreferenceManager.getDefaultSharedPreferences(context)
                .getString(
                        context.getString(R.string.pref_notification_interval_key),
                        context.getString(R.string.pref_default_notification_interval));
        assert string != null;
        return Integer.valueOf(string);
    }
}
