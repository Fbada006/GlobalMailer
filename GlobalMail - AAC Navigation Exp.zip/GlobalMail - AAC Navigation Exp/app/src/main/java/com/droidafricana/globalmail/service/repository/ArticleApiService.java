package com.droidafricana.globalmail.service.repository;

import com.droidafricana.globalmail.service.model.ArticleResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ArticleApiService {
    String BASE_URL = "https://newsapi.org";
    String API_KEY = "cbea6030296f44f283bb6895c74e0d71";

    @GET("/v2/{endPoint}")
    Call<ArticleResponse> getArticleList(@Path("endPoint") String endPoint,
                                         @Query("q") String query,
                                         @Query("category") String category,
                                         @Query("country") String country,
                                         @Query("pageSize") int pageSize,
                                         @Query("sortBy") String sortBy,
                                         @Query("apiKey") String apiKey);
}
