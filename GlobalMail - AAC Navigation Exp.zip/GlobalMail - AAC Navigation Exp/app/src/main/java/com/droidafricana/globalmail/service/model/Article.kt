package com.droidafricana.globalmail.service.model

import com.google.gson.annotations.SerializedName

class Article(
              @field:SerializedName("title")
              val articleTitle: String,
              @field:SerializedName("description")
              val articleDescription: String,
              @field:SerializedName("url")
              val articleUrl: String,
              @field:SerializedName("urlToImage")
              val articleUrlToImage: String,
              @field:SerializedName("publishedAt")
              val articlePublishedAt: String,
              @field:SerializedName("content")
              val articleContent: String)


