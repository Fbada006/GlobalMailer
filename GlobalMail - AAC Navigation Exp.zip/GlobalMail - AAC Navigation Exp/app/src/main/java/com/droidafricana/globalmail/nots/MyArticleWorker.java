package com.droidafricana.globalmail.nots;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.droidafricana.globalmail.view.notifications.ArticleNotificationTasks;

public class MyArticleWorker extends Worker {

    public MyArticleWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        //Issue the notification already
        ArticleNotificationTasks.executeTask(getApplicationContext(),
                ArticleNotificationTasks.ACTION_ISSUE_ARTICLE_NOTIFICATION);
        return Worker.Result.success();
    }
}
