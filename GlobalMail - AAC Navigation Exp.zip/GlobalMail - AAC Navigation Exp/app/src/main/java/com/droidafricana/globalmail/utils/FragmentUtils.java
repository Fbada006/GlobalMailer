package com.droidafricana.globalmail.utils;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.airbnb.lottie.LottieAnimationView;
import com.droidafricana.globalmail.R;
import com.droidafricana.globalmail.view.adapter.MyArticleAdapter;
import com.droidafricana.globalmail.viewModel.ArticleViewModel;

public class FragmentUtils {
    private static final String TAG = "FragmentUtils";


    /**
     * @param fragment         is the owner of the lifecycle
     * @param articleViewModel is the ViewModel with LiveData to observe
     * @param noConnection     is the layout that shows the no network error message
     * @param noArticlesFound  is the layout that shows there are no articles found
     * @param progressBar      is the loading indicator
     * @param myArticleAdapter is the adapter
     */
    public static void observeViewModelForArticles(Context context, Fragment fragment, ArticleViewModel articleViewModel,
                                                   LottieAnimationView noConnection, LinearLayout noArticlesFound,
                                                   LottieAnimationView progressBar, MyArticleAdapter myArticleAdapter) {
        articleViewModel.getArticlesObservable().observe(fragment, listResource -> {
            if (listResource != null) {
                switch (listResource.getStatus()) {
                    case LOADING:
                        noConnection.setVisibility(View.GONE);
                        noArticlesFound.setVisibility(View.GONE);
                        progressBar.setVisibility(View.VISIBLE);
                        break;
                    case SUCCESS:
                        noConnection.setVisibility(View.GONE);
                        progressBar.setVisibility(View.GONE);
                        noArticlesFound.setVisibility(View.GONE);
                        myArticleAdapter.setMArticleList(listResource.getData());
                        myArticleAdapter.notifyDataSetChanged();
                        break;
                    case ERROR:
                        noConnection.setVisibility(View.GONE);
                        progressBar.setVisibility(View.GONE);
                        showErrorToast(context, context.getString(R.string.failed_please_retry));
                        noArticlesFound.setVisibility(View.VISIBLE);
                        break;
                    case NO_NETWORK:
                        noArticlesFound.setVisibility(View.GONE);
                        progressBar.setVisibility(View.GONE);
                        showErrorToast(context, context.getString(R.string.failed_please_retry));
                        noConnection.setVisibility(View.VISIBLE);
                        break;
                    default:
                        break;
                }
            }
        });
    }

    public static void showErrorToast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }
}
