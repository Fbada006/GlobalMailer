package com.droidafricana.globalmail.viewModel;

import static com.droidafricana.globalmail.viewModel.Resources.Status.ERROR;
import static com.droidafricana.globalmail.viewModel.Resources.Status.LOADING;
import static com.droidafricana.globalmail.viewModel.Resources.Status.SUCCESS;

public final class Resources {

    private final Resources.Status status;

    private final Object data;

    public enum Status {
        SUCCESS,
        ERROR,
        LOADING;
    }

    private Resources(Resources.Status status, Object data) {
        this.status = status;
        this.data = data;
    }

    public static Resources success(Object data) {
        return new Resources(SUCCESS, data);
    }

    public static Resources error(Exception exception) {
        return new Resources(ERROR, null);
    }

    public static Resources loading(Object data) {
        return new Resources(LOADING, data);
    }


    public final Resources.Status getStatus() {
        return this.status;
    }

    public final Object getData() {
        return this.data;
    }
}

