package com.droidafricana.globalmail.view.notifications;

import android.content.Context;

import androidx.annotation.NonNull;

import com.droidafricana.globalmail.utils.PrefUtils;
import com.firebase.jobdispatcher.Constraint;
import com.firebase.jobdispatcher.Driver;
import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.firebase.jobdispatcher.Lifetime;
import com.firebase.jobdispatcher.Trigger;

import java.util.concurrent.TimeUnit;

public class ArticleNotificationUtilities {
    private static final String TAG = ArticleNotificationUtilities.class.getSimpleName();

    private static final String ARTICLE_NOTIFICATION_TAG = "article_notification_tag";

    private static boolean sInitialized;

    synchronized public static void scheduleArticleSync(@NonNull final Context context) {
        if (sInitialized) return;

        int notificationWindowInSeconds = 900; //This is fifteen minutes
        int reminderIntervalHours = PrefUtils.notificationInterval(context);
        int reminderIntervalSeconds = (int) TimeUnit.HOURS.toSeconds(reminderIntervalHours);

        Driver driver = new GooglePlayDriver(context);
        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(driver);

        /* Create the Job to periodically create new article notifications */
        Job job = dispatcher.newJobBuilder()
                .setService(ArticleReminderFirebaseJobService.class)
                .setTag(ARTICLE_NOTIFICATION_TAG)
                .setConstraints(Constraint.ON_ANY_NETWORK)
                .setLifetime(Lifetime.FOREVER)
                .setRecurring(true)
                .setTrigger(Trigger.executionWindow(
                        reminderIntervalSeconds,
                        reminderIntervalSeconds + notificationWindowInSeconds))
                .setReplaceCurrent(true)
                .build();

        /* Schedule the Job with the dispatcher */
        dispatcher.schedule(job);

        /* The job has been initialized */
        sInitialized = true;
    }
}
