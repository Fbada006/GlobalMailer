package com.droidafricana.globalmail.view.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.droidafricana.globalmail.R
import com.droidafricana.globalmail.service.model.Article
import com.droidafricana.globalmail.utils.AdapterUtils
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.content_news_item.view.*

private const val VIEW_TYPE_FIRST_ARTICLE = 0
private const val VIEW_TYPE_OTHER_ARTICLES = 1

class MyArticleAdapter(private val mContext: Context) : RecyclerView.Adapter<MyArticleAdapter.MyNewsHolder>() {
    private val mUseFirstItemLayout = mContext.resources.getBoolean(R.bool.use_first_item_layout)
    var mArticleList: List<Article>? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyNewsHolder {

        val layoutId: Int = when (viewType) {
            VIEW_TYPE_FIRST_ARTICLE -> {
                R.layout.first_news_article
            }
            VIEW_TYPE_OTHER_ARTICLES -> {
                R.layout.content_news_item
            }
            else -> throw IllegalArgumentException("Invalid view type, value of $viewType")
        }

        val view = LayoutInflater
                .from(mContext)
                .inflate(layoutId, parent, false)

        return MyNewsHolder(view)
    }

    override fun onBindViewHolder(myViewHolder: MyNewsHolder, position: Int) {
        val currentArticle = mArticleList!![position]
        val articleUrl = currentArticle.articleUrl

        //Set the title of the article
        val articleTitle = currentArticle.articleTitle
        myViewHolder.newsTitle.text = articleTitle

        //Set the description of the article
        val articleDesc = currentArticle.articleDescription
        val articleCont = currentArticle.articleContent
        when {
            (articleDesc != null && articleDesc.isNotEmpty()) -> {
                myViewHolder.newsDescription.text = articleDesc
            }
            (articleCont != null && articleCont.isNotEmpty()) -> {
                myViewHolder.newsDescription.text = articleCont
            }
            else -> myViewHolder.newsDescription.text = articleTitle
        }

        //Check to make sure that the string url is available before requesting the image
        val articleUrlToImage = currentArticle.articleUrlToImage
        if (articleUrlToImage != null && articleUrlToImage.trim { it <= ' ' }.isNotEmpty()) {
            Picasso.get().load(articleUrlToImage).fit().centerCrop()
                    .placeholder(R.drawable.ic_broken_image)
                    .error(R.drawable.ic_broken_image)
                    .into(myViewHolder.imageView)

        } else {
            myViewHolder.imageView.setImageResource(R.drawable.ic_broken_image)
        }

        //Set a listener on the layout to launch Chrome custom tabs with the article URL
        myViewHolder.mCardView.setOnClickListener {
            AdapterUtils.setUpCustomTabs(mContext, articleUrl)
        }
    }

    override fun getItemCount(): Int {
        return mArticleList?.size ?: 0
    }

    override fun getItemViewType(position: Int): Int {
        return if (mUseFirstItemLayout && position == 0) {
            VIEW_TYPE_FIRST_ARTICLE
        } else {
            VIEW_TYPE_OTHER_ARTICLES
        }
    }

    inner class MyNewsHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val newsTitle = itemView.textView_news_title!!
        val newsDescription = itemView.textView_news_description!!
        val imageView = itemView.imageView_news_article!!
        val mCardView = itemView.cardView!!
    }
}
