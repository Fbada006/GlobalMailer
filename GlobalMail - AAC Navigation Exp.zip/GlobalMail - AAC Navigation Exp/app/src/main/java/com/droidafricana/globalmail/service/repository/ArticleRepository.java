package com.droidafricana.globalmail.service.repository;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.droidafricana.globalmail.service.model.Article;
import com.droidafricana.globalmail.service.model.ArticleResponse;
import com.droidafricana.globalmail.viewModel.Resource;

import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.droidafricana.globalmail.service.repository.ArticleApiService.API_KEY;
import static com.droidafricana.globalmail.utils.PrefUtils.getCountry;
import static com.droidafricana.globalmail.utils.PrefUtils.getEndpoint;
import static com.droidafricana.globalmail.utils.PrefUtils.getQueryParam;
import static com.droidafricana.globalmail.utils.PrefUtils.getSortByParam;

public class ArticleRepository {
    private static final String TAG = ArticleRepository.class.getSimpleName();
    private ArticleApiService mArticleApiService;
    private static ArticleRepository sArticleRepository;

    private static final int PAGE_SIZE = 100;

    private ArticleRepository() {
        //TODO: Get rid of this logging
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder()
                .callTimeout(10, TimeUnit.SECONDS)
                .addInterceptor(interceptor)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ArticleApiService.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        mArticleApiService = retrofit.create(ArticleApiService.class);
    }

    //Set up the singleton for the repository and return the repository
    public static synchronized ArticleRepository getInstance(Context context) {
        if (sArticleRepository == null) {
            sArticleRepository = new ArticleRepository();
        }
        return sArticleRepository;
    }

    /*Get the list of the general articles and wrap them in LiveData Objects*/
    public MutableLiveData<Resource<List<Article>>> getArticleList(Context context, String category) {

        final MutableLiveData<Resource<List<Article>>> articleList = new MutableLiveData<>();

        if (isConnected(context)) {
            Call<ArticleResponse> call =
                    mArticleApiService.getArticleList(getEndpoint(context), getQueryParam(context),
                            category, getCountry(context), PAGE_SIZE, getSortByParam(context), API_KEY);

            makeApiCall(context, call, articleList);
        } else {
            articleList.setValue(Resource.Companion.networkError());
        }
        return articleList;
    }

    /*This is the base method to fire up the retrofit call to the network and get the articles*/
    private void makeApiCall(final Context context, Call<ArticleResponse> call, final MutableLiveData<Resource<List<Article>>> articleList) {
        //Show the loading indicator
        articleList.setValue(Resource.Companion.loading());
        call.enqueue(new Callback<ArticleResponse>() {
            @Override
            public void onResponse(@NonNull Call<ArticleResponse> call, @NonNull Response<ArticleResponse> response) {
                assert response.body() != null;
                if (response.body() != null) {
                    if (response.body().getArticleList().size() != 0) {
                        //Hide the indicator and display the news
                        articleList.setValue(
                                Resource.Companion.<List<Article>>success(response.body().getArticleList())
                        );
                    } else {
                        //Hide the indicator and display the error layout
                        articleList.setValue(Resource.Companion.error());
                    }
                } else {
                    //Hide the indicator and display the error layout
                    articleList.setValue(Resource.Companion.error());
                }
            }

            @Override
            public void onFailure(@NonNull Call<ArticleResponse> call, @NonNull Throwable throwable) {
                //Show error toast
                articleList.setValue(Resource.Companion.error());
                Log.e(TAG, "onFailure: ---------" + throwable.toString());
            }
        });
    }

    /*Check for network connectivity first*/
    private boolean isConnected(Context context) {
        ConnectivityManager connectivityManager =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = null;
        if (connectivityManager != null) {
            activeNetwork = connectivityManager.getActiveNetworkInfo();
        }
        return activeNetwork != null && activeNetwork.isConnected();
    }
}
