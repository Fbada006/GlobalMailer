package com.droidafricana.globalmail.utils;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationCompat.Action;
import androidx.core.content.ContextCompat;

import com.droidafricana.globalmail.MainActivity;
import com.droidafricana.globalmail.R;
import com.droidafricana.globalmail.service.model.Article;
import com.droidafricana.globalmail.view.notifications.ArticleNotificationTasks;
import com.droidafricana.globalmail.view.notifications.ArticleReminderIntentService;

/**
 * Utility class for creating article notifications
 */
public class NotificationUtils {

    /*
     * This notification ID can be used to access our notification after we've displayed it.
     */
    private static final int ARTICLE_REMINDER_NOTIFICATION_ID = 1138;
    /**
     * This pending intent id is used to uniquely reference the pending intent
     */
    private static final int ARTICLE_REMINDER_PENDING_INTENT_ID = 3417;
    /**
     * This notification channel id is used to link notifications to this channel
     */
    private static final String ARTICLE_REMINDER_NOTIFICATION_CHANNEL_ID = "reminder_notification_channel";
    private static final int ACTION_IGNORE_ARTICLE_PENDING_INTENT_ID = 14;

    public static void clearAllNotifications(Context context, Article article) {
        NotificationManager notificationManager = (NotificationManager)
                context.getSystemService(Context.NOTIFICATION_SERVICE);
        assert notificationManager != null;
        notificationManager.cancelAll();
    }

    public static void sendArticleNotificationToUser(Context context, Article article) {
        NotificationManager notificationManager = (NotificationManager)
                context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel mChannel = new NotificationChannel(
                    ARTICLE_REMINDER_NOTIFICATION_CHANNEL_ID,
                    context.getString(R.string.main_notification_channel_name),
                    NotificationManager.IMPORTANCE_HIGH);
            assert notificationManager != null;
            notificationManager.createNotificationChannel(mChannel);
        }

        //Use builder pattern to create the notification
        NotificationCompat.Builder notificationBuilder =
                new NotificationCompat.Builder(context, ARTICLE_REMINDER_NOTIFICATION_CHANNEL_ID)
                        .setColor(ContextCompat.getColor(context, R.color.colorPrimary))
                        .setLargeIcon(BitmapFactory.decodeResource(
                                context.getResources(), R.drawable.global_mail_final_logo))
                        .setSmallIcon(R.drawable.global_mail_final_logo)
                        .setContentTitle(article.getArticleTitle())
                        .setContentText(article.getArticleDescription())
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(
                                article.getArticleDescription()))
                        .setDefaults(Notification.DEFAULT_VIBRATE)
                        .setContentIntent(contentIntent(context))
                        .addAction(ignoreNotificationAction(context))
                        .setAutoCancel(true);

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            notificationBuilder.setPriority(NotificationCompat.PRIORITY_HIGH);
        }
        assert notificationManager != null;
        notificationManager.notify(ARTICLE_REMINDER_NOTIFICATION_ID, notificationBuilder.build());
    }

    private static Action ignoreNotificationAction(Context context) {
        Intent ignoreReminderIntent = new Intent(context, ArticleReminderIntentService.class);
        ignoreReminderIntent.setAction(ArticleNotificationTasks.ACTION_DISMISS_NOTIFICATION);
        PendingIntent ignoreReminderPendingIntent = PendingIntent.getService(
                context,
                ACTION_IGNORE_ARTICLE_PENDING_INTENT_ID,
                ignoreReminderIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        return new Action(R.drawable.ic_cancel,
                context.getString(R.string.action_ignore_article_reminder_title),
                ignoreReminderPendingIntent);
    }

    //Pending intent to launch activity
    private static PendingIntent contentIntent(Context context) {
        Intent startActivityIntent = new Intent(context, MainActivity.class);
        return PendingIntent.getActivity(
                context,
                ARTICLE_REMINDER_PENDING_INTENT_ID,
                startActivityIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
    }
}