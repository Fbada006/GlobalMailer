package com.droidafricana.globalmail.view.notifications;

import android.annotation.SuppressLint;
import android.content.Context;

import com.firebase.jobdispatcher.Job;
import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;
import com.firebase.jobdispatcher.RetryStrategy;

public class ArticleReminderFirebaseJobService extends JobService {

    @SuppressLint("StaticFieldLeak")
    @Override
    public boolean onStartJob(final JobParameters jobParameters) {

//        Context context = ArticleReminderFirebaseJobService.this;
//        ArticleNotificationTasks.executeTask(context,
//                ArticleNotificationTasks.ACTION_ISSUE_ARTICLE_NOTIFICATION);

        return true;
    }

    /**
     * Called when the scheduling engine has decided to interrupt the execution of a running job,
     * most likely because the runtime constraints associated with the job are no longer satisfied.
     *
     * @return whether the job should be retried
     * @see Job.Builder#setRetryStrategy(RetryStrategy)
     * @see RetryStrategy
     */
    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        //Return true to signal that the job should be retried if the conditions are met again
        return true;
    }
}