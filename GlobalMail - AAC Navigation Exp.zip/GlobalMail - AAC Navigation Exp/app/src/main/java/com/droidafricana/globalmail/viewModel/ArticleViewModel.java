package com.droidafricana.globalmail.viewModel;

import android.content.Context;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.WorkManager;

import com.droidafricana.globalmail.nots.MyArticleWorkRequest;
import com.droidafricana.globalmail.service.model.Article;
import com.droidafricana.globalmail.service.repository.ArticleRepository;

import java.util.List;

public class ArticleViewModel extends ViewModel {
    private MutableLiveData<Resource<List<Article>>> mArticlesObservable;

    ArticleViewModel(Context context, String articleCategory) {
        getArticleList(context, articleCategory);
    }

    public void getArticleList(Context context, String articleCategory) {
        mArticlesObservable = ArticleRepository.getInstance(context).getArticleList(
                context, articleCategory);
    }

    public MutableLiveData<Resource<List<Article>>> getArticlesObservable() {
        return mArticlesObservable;
    }
}
