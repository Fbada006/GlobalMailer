package com.droidafricana.globalmail.viewModel;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class ArticleViewModelFactory extends ViewModelProvider.NewInstanceFactory {
    private final Context mContext;
    private final String mArticleCategory;

    public ArticleViewModelFactory(Context context, String articleCategory) {
        mContext = context;
        mArticleCategory = articleCategory;
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        return (T) new ArticleViewModel(mContext, mArticleCategory);
    }
}
