package com.droidafricana.globalmail;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.droidafricana.globalmail.chromeCustomTabs.customTabs.CustomTabActivityHelper;
import com.droidafricana.globalmail.view.notifications.ArticleNotificationUtilities;
import com.google.android.material.navigation.NavigationView;

import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements
        CustomTabActivityHelper.ConnectionCallback {

    public static final String TAG = MainActivity.class.getSimpleName();

    private AppBarConfiguration mAppBarConfiguration;
    private NavController mNavController;
    private CustomTabActivityHelper mCustomTabActivityHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.my_nav_host_fragment);

        assert navHostFragment != null;
        mNavController = navHostFragment.getNavController();

        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);

        mAppBarConfiguration = new AppBarConfiguration.Builder(getTopLevelDestinations())
                .setDrawerLayout(drawerLayout)
                .build();

        setupActionBar(mNavController);

        setupNavigationMenu(mNavController);

        ArticleNotificationUtilities.scheduleArticleSync(this);

        //TODO: Enqueue the work Work Manager
//        WorkManager.getInstance().enqueueUniquePeriodicWork(MyArticleWorkRequest.WORK_TAG,
//                ExistingPeriodicWorkPolicy.REPLACE, MyArticleWorkRequest.mPeriodicWorkRequest);

        //TODO: Check memory leaks here
        mCustomTabActivityHelper = new CustomTabActivityHelper();
    }

    /*Helper method for setting the top level destinations of the navigation*/
    private Set<Integer> getTopLevelDestinations() {
        Set<Integer> topLevelDestinations = new HashSet<>();
        topLevelDestinations.add(R.id.top_news_dest);
        topLevelDestinations.add(R.id.sports_news_dest);
        topLevelDestinations.add(R.id.entertainment_news_dest);
        topLevelDestinations.add(R.id.technology_news_dest);
        topLevelDestinations.add(R.id.business_news_dest);
        topLevelDestinations.add(R.id.health_news_dest);
        topLevelDestinations.add(R.id.science_news_dest);
        topLevelDestinations.add(R.id.about_dest);
        return topLevelDestinations;
    }

    private void setupNavigationMenu(NavController navController) {
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setItemIconTintList(null);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    private void setupActionBar(NavController navController) {
        //NavigationUI.setupActionBarWithNavController(this, navController, mDrawerLayout);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return NavigationUI.onNavDestinationSelected(item, mNavController)
                || super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public boolean onSupportNavigateUp() {
        return NavigationUI.navigateUp(mNavController, mAppBarConfiguration);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mCustomTabActivityHelper.setConnectionCallback(null);
        mCustomTabActivityHelper.unbindCustomTabsService(this);
    }

    @Override
    public void onCustomTabsConnected() {
        mCustomTabActivityHelper.getSession();
        Log.d(TAG, "onCustomTabsConnected:----------------------------------- ");
    }

    @Override
    public void onCustomTabsDisconnected() {
        Log.d(TAG, "onCustomTabsDisconnected:----------------------------------- ");
    }

    @Override
    protected void onStart() {
        super.onStart();
        mCustomTabActivityHelper.bindCustomTabsService(this);
    }
}
