package com.droidafricana.globalmail.nots;

import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;

import java.util.concurrent.TimeUnit;

public class MyArticleWorkRequest {
    //Tag to be able to cancel all work of this type if needed
    public static final String WORK_TAG = "article-notification-work";

    private static Constraints mConstraints = new Constraints.Builder()
            //Make sure the work does not run when battery is low
            .setRequiresBatteryNotLow(true)
            //Must have a connection to start the work
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build();

    public static PeriodicWorkRequest mPeriodicWorkRequest =
            new PeriodicWorkRequest.Builder(MyArticleWorker.class, 15, TimeUnit.MINUTES)
                    .setConstraints(mConstraints)
                    .addTag(WORK_TAG)
                    .build();

}
